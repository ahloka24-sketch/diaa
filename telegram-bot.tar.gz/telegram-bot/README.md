# بوت د. ضياء العوضي - نظام الطيبات

بوت تيليجرام لشرح نظام الطيبات وإرسال تذكيرات صيام الإثنين والخميس والأيام البيض.

## المميزات

- ✅ قائمة المسموحات الكاملة
- ❌ قائمة الممنوعات
- 📜 القواعد العامة للنظام
- 🔔 تذكيرات تلقائية لصيام الإثنين والخميس
- 🤍 تذكيرات للأيام البيض (13، 14، 15 هجري)

## المتطلبات

- Python 3.10+
- متغير البيئة `TELEGRAM_BOT_TOKEN` (توكن البوت من @BotFather)

## التشغيل محليًا

```bash
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="ضع_التوكن_هنا"
python main.py
```

## النشر على Render.com (مجاني)

1. ارفع الكود على GitHub.
2. ادخل على [render.com](https://render.com) واعمل حساب.
3. اضغط **New** → **Background Worker**.
4. اختر مستودع GitHub بتاعك.
5. في الإعدادات:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python main.py`
6. في **Environment Variables**:
   - `TELEGRAM_BOT_TOKEN` = توكن البوت من @BotFather
7. اضغط **Create Background Worker**.

## النشر على Railway.app (مجاني)

1. ارفع الكود على GitHub.
2. ادخل على [railway.app](https://railway.app) واعمل حساب.
3. اضغط **New Project** → **Deploy from GitHub repo**.
4. اختر المستودع.
5. في **Variables** أضف:
   - `TELEGRAM_BOT_TOKEN` = توكن البوت
6. Railway هيشغل البوت تلقائيًا.

## الملفات

- `main.py` — الكود الرئيسي للبوت
- `requirements.txt` — مكتبات Python المطلوبة
- `Procfile` — لـ Render/Railway/Heroku
- `.gitignore` — ملفات يتم تجاهلها
